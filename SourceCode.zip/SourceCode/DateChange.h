#include <stdio.h>

//将日期转化为整形表示
int date_change(char* date)
{
    int int_date = 0;
    for(int i=0;i<10;i++)
    {
        if(date[i] == '-')continue;
        else
        {
            int_date = int_date*10+date[i]-48;
        }
    }
    return int_date;
}