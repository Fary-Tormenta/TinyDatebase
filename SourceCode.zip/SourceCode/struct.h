#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

/*
customer
c_custkey--顾客编号
c_mkgsegment--某个市场部门

orders
o_orderkey--订单号
o_custkey--下单顾客编号
o_orderdate--下单时间

lineitem
l_orderkey--订单号
l_extendedprice--价格
l_shipdate--发货时间
*/

typedef struct node
{
    int c_custkey;
    char c_mkgsegment[15];
    struct node* next;
}customers;

typedef struct node_1
{
    int o_custkey;
    int o_orderkey;
    char o_orderdate[10];
    struct node_1* next;
}orders;

typedef struct node_2
{
    int l_orderkey;
    float l_extendedprice;
    char l_shipdate[10];
    struct node_2* next;
}lineitem;

typedef struct node_3
{
    int l_orderkey;
    char o_orderdate[10];
    float total_price;
    struct node_3* next;
}answer;