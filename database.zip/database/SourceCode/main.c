#define _CRT_SECURE_NO_ERROR
#include <stdio.h>
#include <string.h>
#include <Windows.h>
#include <stdlib.h>
#include "struct.h"
#include "DateChange.h"

/*
customer
c_custkey--顾客编号
c_mkgsegment--某个市场部门

orders
o_orderkey--订单号
o_custkey--下单顾客编号
o_orderdate--下单时间

lineitem
l_orderkey--订单号
l_extendedprice--价格
l_shipdate--发货时间
*/

BOOL InOrder(answer* a, answer* b)
{
        answer* temp = (answer*)malloc(sizeof(answer));
        temp->l_orderkey = a->l_orderkey;
        temp->total_price = a->total_price;
        strcmp(temp->o_orderdate, a->o_orderdate);

        a->l_orderkey = b->l_orderkey;
        a->total_price = b->total_price;
        strcmp(a->o_orderdate, b->o_orderdate);

        b->l_orderkey = temp->l_orderkey;
        b->total_price = temp->total_price;
        strcmp(b->o_orderdate, temp->o_orderdate);
        return 1;
}

int main(void)
{
    //读取文件内容
    char path_customer[] = "../customer.txt";
    char path_lineitem[] = "../lineitem.txt";
    char path_orders[] = "../orders.txt";
    FILE* fp_customers, * fp_lineitem, * fp_orders;
    fp_customers = fopen(path_customer,"r");
    fp_lineitem = fopen(path_lineitem,"r");
    fp_orders = fopen(path_orders,"r");
    //作为缓冲区接收文件内容
    char buffer[50];
    if(fp_orders == NULL || fp_customers == NULL || fp_lineitem == NULL){
        printf("Fail to open .txt file.\n");
        goto loop;
    }
    else
    {
        int column_customers = 0, column_orders = 0, column_lineitem = 0;
        //接收customers.txt的内容
        customers* head_customers = (customers*)malloc(sizeof(customers));
        customers* head_customers_hold = (customers*)malloc(sizeof(customers));
        customers* lp_customers = (customers*)malloc(sizeof(customers));

        int head_flag = 0;

        while (!feof(fp_customers))
        {
            column_customers+=1;
            memset(buffer,0,sizeof(buffer));
            fgets(buffer,sizeof(buffer)-1,fp_customers);
            customers* temp_customers = (customers*)malloc(sizeof(customers));
            int temp_custkey = 0, i = 0;
            for(i=0;buffer[i]!='|';i++){
                temp_custkey = temp_custkey * 10 + buffer[i] - 48;
            }
            temp_customers->c_custkey = temp_custkey;
            //使用i来标识‘|’
            i+=1;
            for(int i=0;i<15;i++)if(buffer[i]=='\n')buffer[i]='\000';
            memcpy(temp_customers->c_mkgsegment, &buffer[i], 15);
            // for(int j=0;buffer[i]>=65&&buffer[i]<=90;j++)temp_customers->c_mkgsegment[j]=buffer[i++];

            if(!head_flag){
                printf("1 Linked.\n");
                head_customers = temp_customers;
                head_customers_hold = temp_customers;
                lp_customers = temp_customers;
                head_flag = 1;
            }
            else{
                lp_customers->next = temp_customers;
                lp_customers = temp_customers;
            }
            //用于测试，可以注释掉
            // puts(lp_customers->c_mkgsegment);
            // printf("%s", temp_customers->c_mkgsegment);
            // sleep(1);
        }
        //接收orders.txt的内容
        //测试发现必须要动态开辟空间，否则会出现segmentation fault
        orders* head_orders = (orders*)malloc(sizeof(orders));
        orders* head_orders_hold = (orders*)malloc(sizeof(orders));
        orders* lp_orders = (orders*)malloc(sizeof(orders));

        int head_flag_2 = 0;

        while (!feof(fp_orders))
        {
            column_orders+=1;
            memset(buffer,0,sizeof(buffer));
            fgets(buffer,sizeof(buffer)-1,fp_orders);
            orders* temp_orders = (orders*)malloc(sizeof(orders));

            int temp_o_custkey = 0, temp_o_orderkey = 0, i = 0;
            for(i=0;buffer[i]!='|';i++){
                temp_o_orderkey = temp_o_orderkey * 10 + buffer[i] - 48;
            }
            temp_orders->o_orderkey = temp_o_orderkey;
            i+=1;
            for(int j = 0;buffer[i]!='|';j++){
                temp_o_custkey = temp_o_custkey * 10 + buffer[i++] - 48;
            }
            temp_orders->o_custkey = temp_o_custkey;
            i+=1;
            for(int i=0;i<15;i++)if(buffer[i]=='\n')buffer[i]='\000';
            memcpy(temp_orders->o_orderdate, &buffer[i], 10);

            if(!head_flag_2){
                printf("2 Linked.\n");
                head_orders->next = temp_orders;
                head_orders_hold = temp_orders;
                lp_orders = temp_orders;
                head_flag_2 = 1;
            }
            else{
                lp_orders->next = temp_orders;
                lp_orders = temp_orders;
            }
            
            //以下是测试代码，可以注释
            // for(int i=0;i<10;i++)
            //     printf("%c", temp_orders->o_orderdate[i]);
            // printf("\n");
        }
        //接收lineitem.txt的内容
        lineitem* head_lineitem = (lineitem*)malloc(sizeof(lineitem));
        lineitem* head_lineitem_hold = (lineitem*)malloc(sizeof(lineitem));
        lineitem* lp_lineitem = (lineitem*)malloc(sizeof(lineitem));

        int head_flag_3 = 0;

        while(!feof(fp_lineitem))
        {
            column_lineitem+=1;
            memset(buffer,0,sizeof(buffer));
            fgets(buffer,sizeof(buffer)-1,fp_lineitem);
            lineitem* temp_lineitem = (lineitem*)malloc(sizeof(lineitem));

            int i = 0, temp_l_orderkey = 0;
            for(i=0;buffer[i]!='|';i++){
                temp_l_orderkey = temp_l_orderkey * 10 + buffer[i] - 48;
            }
            temp_lineitem->l_orderkey = temp_l_orderkey;
            i+=1;
            int temp_price = 0;
            int point = 0.1;
            for(int j=0;buffer[i]!='.';j++)
                temp_price+=temp_price*10+buffer[i++]-48;
            i+=1;
            for(int j=0;buffer[i]!='|';j++)
            {
                temp_price+=(buffer[i++] - 48) * point;
                point*=point;
            }
            temp_lineitem->l_extendedprice = temp_price;
            i+=1;
            for(int i=0;i<15;i++)if(buffer[i]=='\n')buffer[i]='\000';
            memcpy(temp_lineitem->l_shipdate, &buffer[i], 10);

            if(!head_flag_3){
                printf("3 Linked.\n");
                head_lineitem->next = temp_lineitem;
                head_lineitem_hold = temp_lineitem;
                lp_lineitem = temp_lineitem;
                head_flag_3 = 1;
            }
            else{
                lp_lineitem->next = temp_lineitem;
                lp_lineitem = temp_lineitem;
            }
            
            //以下是测试函数
            // for(int i=0;i<10;i++)
            //     printf("%c", temp_lineitem->l_shipdate[i]);
            // printf("\n");
        }
        //数据接收完毕，下面开始比对
        char mkgsegment[15];
        char date_1[10], date_2[10];
        int times = 0;
        //保持格式一致
        // char mkgsegment[] = "BUILDING";
        // char date_1[] = "1995-03-27", date_2[] = "1995-03-29";
        // times = 1;
        //不可以直接mkgsegment，要使用首字符地址
        loop1:memset(mkgsegment, 0, sizeof(mkgsegment));
        printf("input mksegment:");
        scanf("%s", &mkgsegment[0]);
        getchar();
        printf("input date_1:");
        for(int i=0;i<10;i++)scanf("%c", &date_1[i]);
        getchar();
        // scanf("%s", date_1);
        printf("input date_2:");
        for(int i=0;i<10;i++)scanf("%c", &date_2[i]);
        // scanf("%s", date_2);
        printf("input how many records do you want:");
        scanf("%d", &times); 

        /*customers* lp_customers = (customers*)malloc(sizeof(customers));
        orders* lp_orders = (orders*)malloc(sizeof(orders));
        lineitem* lp_lineitem = (lineitem*)malloc(sizeof(lineitem));*/

        answer* head_answer = (answer*)malloc(sizeof(answer));
        answer* lp_answer = (answer*)malloc(sizeof(answer));

        lp_customers = head_customers_hold;
        lp_orders = head_orders_hold;
        lp_lineitem = head_lineitem_hold;

        int temp_times = 0;
        int flag_customers = 0, flag_orders = 0, flag_lineitem = 0, flag_answer = 0;
        int count_answer = 0;
        
        while(temp_times<times){
            int date1 = date_change(date_1);
            int date2 = date_change(date_2);
            int check_customers = 0, check_orders = 0, check_lineitem = 0;
            while(strcmp(lp_customers->c_mkgsegment, mkgsegment)!=0){
                check_customers++;
                if(check_customers == column_customers){
                    if(flag_customers == 1){
                        flag_customers = 0;
                        check_customers = 0;
                        printf("Customers Input Error.\n");
                        goto loop;
                    }
                    lp_customers = head_customers_hold;
                    flag_customers = 1;
                    check_customers = 0;
                }
                lp_customers = lp_customers->next;
            }
            while(lp_customers->c_custkey != lp_orders->o_custkey)
            {
                // printf("%d\n", lp_orders->o_custkey);
                check_orders++;
                if(check_orders == column_orders){
                    if(flag_orders == 1){
                        flag_orders = 0;
                        check_orders = 0;
                        printf("Orders Input Error.\n");
                        goto loop;
                    }
                    lp_orders = head_orders_hold;
                    flag_orders = 1;
                    check_orders = 0;
                }
                lp_orders = lp_orders->next;
            }
            while(lp_orders->o_orderkey!=lp_lineitem->l_orderkey)
            {
                check_lineitem++;
                if(check_lineitem == column_lineitem){
                    if(flag_lineitem == 1){
                        flag_lineitem = 0;
                        check_lineitem = 0;
                        printf("Lineitem Input Error.\n");
                        goto loop;
                    }
                    lp_lineitem = head_lineitem_hold;
                    flag_lineitem = 1;
                    check_lineitem = 0;
                }
                lp_lineitem = lp_lineitem->next;
            }
            int o_orderdate = date_change(lp_orders->o_orderdate);
            int l_shipdate = date_change(lp_lineitem->l_shipdate);
            if(o_orderdate < date1 && l_shipdate > date2){
                count_answer+=1;
                answer* temp_answer = (answer*)malloc(sizeof(answer));
                if(!flag_answer){
                    head_answer = temp_answer;
                    lp_answer = temp_answer;
                    flag_answer = 1;
                }
                else
                {
                    lp_answer->next = temp_answer;
                    lp_answer = temp_answer;
                }
                memcpy(temp_answer->o_orderdate, lp_orders->o_orderdate, 10);
                temp_answer->l_orderkey = lp_lineitem->l_orderkey;
                temp_answer->total_price = lp_lineitem->l_extendedprice;
            }
            temp_times+=1;
            lp_customers = lp_customers->next;
            lp_lineitem = lp_lineitem->next;
            lp_orders = lp_orders->next;
        }

        int total_count = 0, total_answer = 0, total_flag = 0, total = 0;
        //total是合并后解的个数
        answer* total_head = (answer*)malloc(sizeof(answer));
        answer* total_lp = (answer*)malloc(sizeof(answer));
        answer* total_lp_1 = (answer*)malloc(sizeof(answer));
        answer* total_lp_2 = (answer*)malloc(sizeof(answer));
        total_head = head_answer;
        total_lp = head_answer;
        while (total_answer<times)
        {
            answer* total_temp = (answer*)malloc(sizeof(answer));
            total_temp->l_orderkey = total_lp->l_orderkey;
            strcmp(total_temp->o_orderdate, total_lp->o_orderdate);
            total_temp->total_price = total_lp->total_price;
            total_answer+=1;
            if(total_flag == 0){
                total_head->l_orderkey = total_temp->l_orderkey;
                strcmp(total_head->o_orderdate, total_temp->o_orderdate);
                total_head->total_price = total_temp->total_price;
                total_lp_2 = total_head;
                total_flag = 1;
                total+=1;
            }
            else{
                total_lp_1 = total_head;
                //判断是否有orderkey相同项
                int temp = 0;
                while(total_count<total_answer)
                {
                    total_count+=1;
                    if(total_lp->l_orderkey == total_lp_1->l_orderkey)
                    {
                        total_lp_1->total_price+=total_lp->total_price;
                        temp = 1;
                        total+=1;
                    }
                    else
                    {
                        total_lp_1 = total_lp_1->next;
                    }
                }
                if(temp == 0)
                {
                    total_lp_2->next = total_temp;
                    total_lp_2 = total_temp;
                    total+=1;
                }
            }
            total_lp = total_lp->next;
        }

        //排序
        answer order[total];
        total_lp = total_head;
        for(int i=0;i<total;i++){
            order[i].l_orderkey = total_lp->l_orderkey;
            order[i].total_price = total_lp->total_price;
            for(int j=0;j<10;j++)order[i].o_orderdate[j] = total_lp->o_orderdate[j];
            total_lp = total_lp->next;
        }
        int temp = 0;
        int temp_2 = total;
        total_lp = total_head;
        while (temp<total)
        {
            int j = 0;
            answer* temp_a = (answer*)malloc(sizeof(answer));
            temp_a->total_price = 0;
            for(int i=temp;i<total;i++){
                if(temp_a->total_price<order[i].total_price){
                    temp_a->total_price = order[i].total_price;
                    j = i;
                }
            }
            InOrder(&order[temp], &order[j]);
            temp+=1;
            total_lp = total_lp->next;
        }

        if(count_answer == 0){
            printf("Not Found.\n");
            return 0;
        }
        lp_answer = head_answer;
        for(int i=0;i<40;i++)printf("-");
        printf("\n");
        temp_times = 0;
        while (temp_times<total)
        {
            printf("|  %10d|  %10.2f|  %s|\n", order[temp_times].l_orderkey, order[temp_times].total_price, order[temp_times].o_orderdate);
            for(int i=0;i<40;i++)printf("-");
            printf("\n");
            temp_times+=1;
        }

        printf("Continue(Y|N): ");
        char Y_N;
        getchar();
        scanf("%c", &Y_N);
        if(Y_N == 'Y')goto loop1;
    
        free(head_answer);
        free(lp_customers);
        free(lp_orders);
        free(lp_lineitem);
        // free(head_answer);
    }

    loop:fclose(fp_lineitem);
    fclose(fp_orders);
    fclose(fp_customers);
    system("pause");
    return 0;
}